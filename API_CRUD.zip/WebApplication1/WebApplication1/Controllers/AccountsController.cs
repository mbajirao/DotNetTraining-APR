﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class AccountsController : Controller
    {
        private ProjectContext _context;
        public AccountsController(ProjectContext context)
        {
            _context = context;
        }
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(UserLogin lg)
        {
            UserMaster um = new UserMaster();
            
               um= _context.Users.Where(x => x.UserId == lg.UserId && x.Password == lg.Password)
                    .FirstOrDefault();
            
            if(um!=null)
            {
                HttpContext.Session.SetString("name", um.Name);
                HttpContext.Session.SetInt32("role", um.Role);

                if(um.Role==1)
                {
                    return RedirectToAction("Index", "Admin");
                }
                else
                {
                    return RedirectToAction("Index", "User");
                }
            }
            else
            {
                TempData["msg"] = "Incorrect Userid/Password";
            }
                return View();
        }


        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
