﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemsController : ControllerBase
    {
        private StoreContext _context;
        public ItemsController(StoreContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var products = _context.Products.ToList();
            return Ok(products);
        }

        [HttpGet]
        [Route("{id}")]
        public IActionResult GetProduct(int id)
        {
            return Ok(_context.Products.Find(id));
        }


        [HttpDelete]
        [Route("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            var product = _context.Products.Find(id);
            if (product != null)
            {
                _context.Remove(product);
                _context.SaveChanges();
                return Ok(product);
            }
            else
            {
                return NotFound();
            }

        }


        [HttpPost]
        public IActionResult AddProduct([FromBody] Product product)
        {
            _context.Products.Add(product);

            if (_context.SaveChanges()>0)
            {               
                return Ok(product);
            }
            else
            {
                return NotFound();
            }

        }

        [HttpPut]
        [Route("{id}")]
        public IActionResult UpdateProduct(int id,[FromBody] Product product)
        {
            Product? prod = _context.Products.Find(id);
            if(prod!=null)
            {
                _context.Products.Update(product);
                _context.SaveChanges();
                return Ok();
            }
            else
            {
                return NotFound();
            }

        }
    }
}
}
