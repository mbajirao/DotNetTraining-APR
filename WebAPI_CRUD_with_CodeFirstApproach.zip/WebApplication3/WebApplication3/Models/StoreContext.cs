﻿using Microsoft.EntityFrameworkCore;

namespace WebApplication3.Models
{
    public class StoreContext:DbContext
    {
        public DbSet<Product> Products { get; set; }
        public StoreContext(DbContextOptions options):base(options)
        {
            
        }
    }
}
