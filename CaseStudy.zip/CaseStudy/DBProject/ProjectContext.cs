﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBProject
{
    public class ProjectContext:DbContext
    {
        public DbSet<MenuItem> Menus { get; set; }
        public DbSet<UserDetails> User { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer
    ("Data Source=DESKTOP-7ADL9CQ;Initial Catalog=ProjectDB;Integrated Security=true;TrustServerCertificate=true");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserDetails>().HasData(
                new UserDetails {Id=1,Name="TestAdmin",RoleId=1,IsActive=true,UserId="admin",Password="123456" },
                new UserDetails {Id=2,Name="TestUser",RoleId=2,IsActive=true,UserId="test",Password="123456" }
                );

            modelBuilder.Entity<MenuItem>().HasData(
                new MenuItem {Id=1,Category="Main Course",Name="Biryani",Price=199,FreeDelivery=true,IsActive=true },
                new MenuItem {Id=2,Category="Main Course",Name="Butter Nan",Price=69,FreeDelivery=false,IsActive=false },
                new MenuItem {Id=3,Category="Main Course",Name="Sandwitch",Price=109,FreeDelivery=false,IsActive=true },
                new MenuItem {Id=4,Category="Soft Drinks",Name="Coke",Price=60,FreeDelivery=true,IsActive=true },
                new MenuItem {Id=5,Category="Desserts",Name="Chocolate Brownie",Price=79,FreeDelivery=true,IsActive=true }
                );
        }
    }
}
