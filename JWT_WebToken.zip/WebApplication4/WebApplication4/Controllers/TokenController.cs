﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace WebApplication4.Controllers
{
    public class TokenController : Controller
    {
        private const string SecretKey = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";

        public static readonly SymmetricSecurityKey SIGNING_KEY = 
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(TokenController.SecretKey));

        private string GenerateToken(string userid)
        {
            var token = new JwtSecurityToken(
                claims:new Claim[]
                {
                    new Claim(ClaimTypes.Name, userid)
                },
                notBefore:new DateTimeOffset(DateTime.Now).DateTime,
                expires: new DateTimeOffset(DateTime.Now.AddMinutes(5)).DateTime,
                signingCredentials:new SigningCredentials(SIGNING_KEY,SecurityAlgorithms.HmacSha256)
                );
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        [HttpGet]
        [Route("api/Token/{userid}/{password}")]
        public IActionResult Get(string userid,string password)
        {
            if(userid==password)
            {
                return Ok(GenerateToken(userid));
            }
            else
            {
                return BadRequest();
            }
        }

    }
}
