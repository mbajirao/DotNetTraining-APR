﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication4.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        [HttpGet]
        [Route("api/values/GetData")]
        [AllowAnonymous]
        public IActionResult GetData()
        {
            return Ok(new string[] {"Angular","React","Vue","Ecma Script" });
        }

        [HttpGet]
        [Route("api/values/courses")]
        [Authorize]
        public IActionResult GetList()
        {
            return Ok(new string[] { "Angular", "React", "Vue", "Ecma Script" });
        }
    }
}
