﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        public static List<Employee> Employees = new List<Employee>
        {
            new Employee{Id=905201,Name="User1",Designation="IT-Dev",Salary=65000 },
            new Employee{Id=905202,Name="User2",Designation="IT-Dev",Salary=65000 },
            new Employee{Id=905203,Name="User3",Designation="IT-Dev",Salary=65000 },
            new Employee{Id=905204,Name="User4",Designation="IT-Dev",Salary=65000 },
            new Employee{Id=905205,Name="User5",Designation="IT-Dev",Salary=65000 },
        };


        [HttpGet]
        [Route("All")]
        public ActionResult<List<Employee>> GetUsers()
        {
            //string[] names = new string[] {"Raj","Kiran","Priya","Krishna" };
            return Ok(Employees);
        }

        [HttpGet]
        [Route("{id}")]
        public ActionResult<Employee> GetUser(int id)
        {
            var emp=Employees.Where(x => x.Id == id).FirstOrDefault();

            if (emp != null)
            {
                return Ok(emp);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        public ActionResult AddUser([FromBody]Employee emp)
        {
            Employees.Add(emp);
            return Ok();
        }

        [HttpPut]
        [Route("{id}")]
        public IActionResult UpdateUser(int id,[FromBody] Employee emp)
        {
            var employee = Employees.Where(x => x.Id == id).FirstOrDefault();
            employee.Name = emp.Name;
            employee.Designation = emp.Designation;
            employee.Salary = emp.Salary;
            return Ok();
        }

        [HttpDelete]
        [Route("{id}")]
        public IActionResult DeleteUser(int id)
        {
            var employee = Employees.Where(x => x.Id == id).FirstOrDefault();
            Employees.Remove(employee);
            return Ok();
        }
    }
}
