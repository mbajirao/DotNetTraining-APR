﻿using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models
{
    public class ProjectContext:DbContext
    {
        public DbSet<UserMaster> Users { get; set; }
        public DbSet<Product> Products { get; set; }

        public ProjectContext()
        {
            
        }
        public ProjectContext(DbContextOptions options):base(options)
        {            
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserMaster>().HasData(
                new UserMaster {Id=1,Name="Test Admin",UserId="admin",Password="test@123",Role=1 },
                new UserMaster {Id=2,Name="Test User",UserId="user",Password="test@123",Role=2 }
                );
        }

    }
}
