using ConsumeAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text.Json;

namespace ConsumeAPI.Controllers
{
    public class HomeController : Controller
    {
       
        public async Task<IActionResult> Index()
        {
            List< Employee> employees = new List< Employee >();
            var _httpClient = new HttpClient();
            var response = await _httpClient.GetAsync("http://localhost:5071/api/Users/All");
            if(response.IsSuccessStatusCode)
            {
                var content= await response.Content.ReadAsStringAsync();
                employees = JsonConvert.DeserializeObject<List<Employee>>(content);
            }


            return View(employees);
        }

        
        public async Task<Employee> GetEmployee(int id)
        {
           Employee emp = new Employee();
            var _httpClient = new HttpClient();
            var response = await _httpClient.GetAsync("http://localhost:5071/api/Users/"+id);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                emp = JsonConvert.DeserializeObject<Employee>(content);
            }

            return emp;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public ActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> AddAsync(Employee emp)
        {
            var _httpClient = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(emp), 
                System.Text.Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync("http://localhost:5071/api/Users",content );
            if(response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return View();
        }


        public async Task<ActionResult> Edit(int id)
        {
            Employee emp = new Employee();
            var _httpClient = new HttpClient();
            var response = await _httpClient.GetAsync("http://localhost:5071/api/Users/" + id);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                emp = JsonConvert.DeserializeObject<Employee>(content);
            }
            return View(emp);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Employee emp)
        {
            var _httpClient = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(emp),
                System.Text.Encoding.UTF8, "application/json");
            var response = await _httpClient.PutAsync("http://localhost:5071/api/Users/"+emp.Id, content);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public async Task<ActionResult> Delete(int id)
        {
            Employee emp = new Employee();
            var _httpClient = new HttpClient();
            var response = await _httpClient.DeleteAsync("http://localhost:5071/api/Users/" + id);
           
            return RedirectToAction("Index");
        }
    }
}
