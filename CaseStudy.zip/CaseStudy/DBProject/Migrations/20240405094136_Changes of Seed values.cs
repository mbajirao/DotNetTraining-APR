﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace DBProject.Migrations
{
    /// <inheritdoc />
    public partial class ChangesofSeedvalues : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Menus",
                columns: new[] { "Id", "Category", "FreeDelivery", "IsActive", "Name", "Price" },
                values: new object[,]
                {
                    { 1, "Main Course", true, true, "Biryani", 199.0 },
                    { 2, "Main Course", false, false, "Butter Nan", 69.0 },
                    { 3, "Main Course", false, true, "Sandwitch", 109.0 },
                    { 4, "Soft Drinks", true, true, "Coke", 60.0 },
                    { 5, "Desserts", true, true, "Chocolate Brownie", 79.0 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Menus",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Menus",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Menus",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Menus",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Menus",
                keyColumn: "Id",
                keyValue: 5);
        }
    }
}
