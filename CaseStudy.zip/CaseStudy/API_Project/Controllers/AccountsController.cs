﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DBProject;

namespace API_Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        private ProjectContext _context;
        public AccountsController()
        {
            _context = new DBProject.ProjectContext();
        }
        [HttpGet]
        [Route("/login/{userid}/{password}")]
        public IActionResult LoginValidate(string userid,string password)
        {
            try
            {
                UserDetails? user = _context.User.Where(x => x.UserId == userid && x.Password == password)
                    .FirstOrDefault();
                if (user != null)
                {
                    return Ok(user);
                }
                else
                {
                    return NotFound();
                }
            }
            catch
            {
                return BadRequest();
            }
          
        }
    }
}
