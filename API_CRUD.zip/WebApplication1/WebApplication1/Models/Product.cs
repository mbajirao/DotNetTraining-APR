﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Product
    {
        [Key]
        public int Pid { get; set; }

        [Required(ErrorMessage ="Name is Required")]
        public string Name { get; set; }

        [Required(ErrorMessage ="Barcode is Required")]
        [RegularExpression("^[ARar]{1}[0-9]{9}$",ErrorMessage ="Invalid Barcode")]
        public string Barcode { get; set; }

        [Required(ErrorMessage ="Category Id is Required")]
        [RegularExpression("^[0-9]{6}$",ErrorMessage ="Invalid Category Id")]
        [Display(Name ="Category Code")]
        public string CategoryId { get; set; }

        [Required(ErrorMessage ="Price is Required")]
        public double Price { get; set; }

        public bool IsActive { get; set; }


    }
}
